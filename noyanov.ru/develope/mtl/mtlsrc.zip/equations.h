#include "matrix.h"

#ifndef _EQUATION_
#define _EQUATION_

#define __STD_COMPLEX

#include <math.h>
#include <complex>

const int NONE_INVERT_MATRIX = -1;
const int FULL_INVERT_MATRIX = 0;
const int DIAGONAL_INVERT_MATRIX = 1;

/**
* Equation Package
* Extension of Matrix package for equation systems resolving.
* Thank to OOL C++ one can use equation system as C++ objects
* and can make operations with them via C++ operation calls.
* 
* The package is written by Urry Noyanov for it' dissertation work.
* It is free distributable as is and with condition of mention of U.Noyanov authorship.
*
* (C) 1997 by Urry Noyanov (by the therms above)
*	@Started: Oct 1997
*	@Author: Noyanov U.G.
**/

/** Equation Systems.
* Equation system is written in matrixes as Ax=B
* there A is coeffiecients matrix,
*		B is vector of free members
*	and x is vector of unknowns
*
* The most common case is EquationSystem that is represented with SquareMatrix A
* The more simple case is NormalEquation that is represented with SymmetricMatrix A
**/

/**
*	Equation system Ax=B.
*	The equation system is resolved by Holetsky decomposition method.
*	The initial matrix A is represented as two triangle matrix A=T1 * T2
**/
template<class MatrixType> class EquationSystem : public SquareMatrix<MatrixType>
{
protected:
	Vector<MatrixType> m_B;
	TriangleMatrix<MatrixType> *m_TB,*m_TC;
public:
	EquationSystem(int N,MatrixType* initial_data=NULL,MatrixType* initial_free_members=NULL)
		: SquareMatrix<MatrixType>(N,initial_data),
			m_B(N,false,initial_free_members)
	{
		m_TB=NULL;
		m_TC=NULL;
	}
	~EquationSystem()
	{
		if(m_TB) { delete m_TB; m_TB=NULL; }
		if(m_TC) { delete m_TC; m_TC=NULL; }
	}

	void SetB(int i,MatrixType value) 
	{ 
		m_B(i)=value;
	}
	MatrixType GetB(int i) const 
	{ 
		return m_B(i);
	}
	Vector<MatrixType> Resolve(bool& OK);
	Vector<MatrixType>& ResolveItself(bool& OK);
	Vector<MatrixType>& GetX() { return m_B; }
	TriangleMatrix<MatrixType>& GetTB() { return *m_TB; }
	TriangleMatrix<MatrixType>& GetTC() { return *m_TC; }
protected:
	bool Resolving(SquareMatrix<MatrixType>& B,
				   SquareMatrix<MatrixType>& C,
				   Vector<MatrixType>& x);
};

// Resolve Equation system by SQRT-method
template<class MatrixType> 
	Vector<MatrixType> EquationSystem<MatrixType>::Resolve(bool& OK)
{
	if(m_TB) { delete m_TB; m_TB=NULL; }
	if(m_TC) { delete m_TC; m_TC=NULL; }
	m_TB=new TriangleMatrix<MatrixType>(m_rows,true);
	assert(m_TB);
	m_TC=new TriangleMatrix<MatrixType>(m_rows,false);
	assert(m_TC);
	Vector<MatrixType> x(m_rows,false);
	OK=Resolving(*m_TB,*m_TC,x);
	return x;
}

template<class MatrixType> 
	Vector<MatrixType>& EquationSystem<MatrixType>::ResolveItself(bool& OK)
{
	OK=Resolving(*this,*this,m_B);
	return m_B;
}

template<class MatrixType> 
	bool EquationSystem<MatrixType>::Resolving(SquareMatrix<MatrixType>& B,
												SquareMatrix<MatrixType>& C,
												Vector<MatrixType>& x)
{
	// Step 1. Represents matrix A as two triangle matrixes B and C
	//		   by Holetsky decomposition.
	//		( B is low triangle matrix and C is up triangle matrix with identity diagonal)
	if(!Decomposite(B,C)) return false;

	// Step 2a). Calculate Y
	Vector<MatrixType> y(N);
	for(int i=1;i<=N;i++) 
	{
		MatrixType sumBY=0;
		for(int k=1;k<i;k++) 
			sumBY+=( B(i,k)*y(k) );
		if(B(i,i)==0) return false;
		MatrixType v=(m_B(i)-sumBY)/B(i,i); // B(i,i) are already checked
		y(i)=v;
	}

	// Step 2b). Calcuate X
	for( i=N;i>0;i--)
	{
		MatrixType sumCX=0;
		for(int k=i+1;k<=N;k++) 
			sumCX+=( C(i,k)*x(k) );
		MatrixType v=y(i)-sumCX;
		x(i)=v;
	}
	return true;
}

/////////////////////////////
/**
*	Normal Equation system Ax=B.
*	The normal equation system is resolved by LU decomposition method.
*	The initial matrix A is represented as two triangle matrix A=T * T(T)
**/
template<class MatrixType> class NormalEquationSystem : public SymmetricMatrix<MatrixType>
{
protected:
	Vector<MatrixType> m_B;
	TriangleMatrix<MatrixType> *m_T;
	MatrixType m_diagonal_sum;
public:
	NormalEquationSystem(int N,MatrixType* initial_data=NULL,MatrixType* initial_free_members=NULL)
		: SymmetricMatrix<MatrixType>(N,initial_data),
			m_B(N,false,initial_free_members)
	{
		m_T=NULL;
	}

	NormalEquationSystem(SymmetricMatrix<MatrixType> A,Vector<MatrixType> B)
		: SymmetricMatrix<MatrixType>(A),
		  m_B(B)
	{
		m_T=NULL;
	}

	~NormalEquationSystem()
	{
		if(m_T) { delete m_T; m_T=NULL; }
	}
	void SetB(int i,MatrixType value) 
	{ 
		m_B(i)=value;
	}
	const MatrixType GetB(int i) const 
	{ 
		return m_B(i);
	}
	Vector<MatrixType>& GetX() { return m_B; }
	TriangleMatrix<MatrixType>& GetT() { return *m_T; }
	Vector<MatrixType> Resolve(bool& OK);
	Vector<MatrixType>& ResolveItself(bool& OK);

protected:
	bool Resolving(SquareMatrix<MatrixType>& T,Vector<MatrixType>& x);
};

// Resolve Equation system by SQRT-method
template<class MatrixType> 
	Vector<MatrixType> NormalEquationSystem<MatrixType>::Resolve(bool& OK)
{
	if(m_T) { delete m_T; m_T=NULL; }
	m_T=new TriangleMatrix<MatrixType>(GetRows(),false);
	assert(m_T);
	Vector<MatrixType> x(GetRows(),false);
	OK=Resolving((*m_T),x);
	return x;
}

template<class MatrixType> 
	Vector<MatrixType>& NormalEquationSystem<MatrixType>::ResolveItself(bool& OK)
{
	OK=Resolving(*this,m_B);
	return m_B;
}

// The core function.
// It is too large and was excluded from inline class list
template<class MatrixType> 
	bool NormalEquationSystem<MatrixType>::Resolving(SquareMatrix<MatrixType>& T,
												     Vector<MatrixType>& x)
{
	// Step 1. Represents matrix A as two triangle matrixes T1 and T2 that 
	//		    are simmetric each other.
	// iscomplex is array of flags to handle complex numbers
	int N=GetRows();
	Vector<int> iscomplex(N);
	Decomposite(T,iscomplex);
	// Step 2. Decides two equation T2*y=B and T1*x=B
	// 2a). Forward step. Y calculation
	Vector<MatrixType> y(N);
	for(int i=1;i<=N;i++) 
	{
		MatrixType sumTY=0;
		for(int k=1;k<i;k++)
		{
			MatrixType TY=T(k,i)*y(k);
			if(iscomplex(k)) sumTY-=TY;
			else			 sumTY+=TY;
		}
		MatrixType yi=(m_B(i)-sumTY)/T(i,i); // (Tii already checked above)
		if(iscomplex(i)) yi=-yi;
		y(i)=yi;
	}
	// vector Y have been calculated
	// 2b).Backward step.
	// go to X calcuation
	std::complex<MatrixType> *cx=new std::complex<MatrixType>(N+1);
	for( i=N;i>0;i--)
	{   
		std::complex<MatrixType> ct(0,0),sumTX(0,0);
		for(int k=i+1;k<=N;k++)
		{
			if(iscomplex(i)) ct=std::complex<MatrixType>(0,T(i,k));
			else			 ct=std::complex<MatrixType>(T(i,k),0);
			sumTX+=ct*cx[k];
		}
		std::complex<MatrixType> cy(0,0),ctii(0,0),cxi(0,0);
		if(iscomplex(i)) 
		{
			cy=std::complex<MatrixType>(0,y(i));
			ctii=std::complex<MatrixType>(0,T(i,i));
		}
		else
		{
			cy=std::complex<MatrixType>(y(i),0); 
			ctii=std::complex<MatrixType>(T(i,i),0);
		}
		cx[i]=(cy-sumTX)/ctii;
		//assert(cxi.imag()!=0); 
	}
	// X have been calculated. 
	// The equation system have been resolved.
	bool bComplex=false;
	for( i=1;i<=N;i++) 
	{
		x(i)=cx[i].real();
		if(cx[i].imag()!=0) bComplex=true;
	}
	delete cx;

	// Addition step may requirest. This is matrix T inverstion
	// To do it call GetT() to get T matrix and call T.InverseItself();
	return !bComplex;
}


/**
*	Redundand Equation system Ax=~B.
*	there A(mxn) is not square matrix (m>n)
*	The equation system is resolved by least squares methods.
*	The initial matrix system is resolved by leading into square matrix 
*	by multiplication both its parts to AT.
**/
template<class MatrixType> class RedundandEquationSystem : public Matrix<MatrixType>
{
protected:
	Matrix<MatrixType> m_B;
public:
	RedundandEquationSystem(int M,int N,MatrixType* initial_data=NULL,MatrixType* initial_free_members=NULL)
		: Matrix<MatrixType>(M,N,initial_data),
			m_B(M,1,initial_free_members)
	{
		assert(M>N);
	}
	~RedundandEquationSystem()
	{
	}

	void SetB(int i,MatrixType value) 
	{ 
		m_B(i,1)=value;
	}
	MatrixType GetB(int i) const 
	{ 
		return m_B(i,1);
	}

	Vector<MatrixType> Resolve(bool& OK);
};

// Resolve Equation system by SQRT-method
template<class MatrixType> 
	Vector<MatrixType> RedundandEquationSystem<MatrixType>::Resolve(bool& OK)
{
	Matrix<MatrixType> AT(Transpose());
	NormalEquationSystem NES(m_rows, (AT*(*this)).GetData(), (AT*m_B).GetData() );
	return NES.Resolve(OK);
}

#endif
