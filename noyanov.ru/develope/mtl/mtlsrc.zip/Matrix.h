#ifndef _MATRIX_
#define _MATRIX_

#include <stdlib.h>
#include <stdio.h>
#include <memory.h>
#include <math.h>
#include <iomanip.h>
#include <iostream.h>
#include <fstream.h>
#include <io.h>
#include <assert.h>

/**************************************************************************
**
** Copyright (C) 1998 Yurry G. Noyanov, all rights reserved.
**
**               Matrix Template Class Package
**
** This Matrix Template Class Package is provided "as is" without any express
** or implied warranty of any kind with respect to this software.
** In particular the authors shall not be liable for any direct,
** indirect, special, incidental or consequential damages arising
** in any way from use of the software.
**
** Everyone is granted permission to copy, modify and redistribute this
** Matrix Template Class Package, provided:
**  1.  All copies contain this copyright notice.
**  2.  All modified copies shall carry a notice stating who
**      made the last modification and the date of such modification.
**  3.  No charge is made for this software or works derived from it.
**      This clause shall not be construed as constraining other software
**      distributed on the same medium as this software, nor is a
**      distribution fee considered a charge.
**
***************************************************************************/
/////
 // Purpose:
 //  Package of matrix classes.
 //  Containes set of C++ template classes that incupsulates matrix functionality.
 //  The classes set is extended to special cases of matrix - band and grow matrix.
 //  Template classes incorporated into the Matrix Template Class Package:
 //  o Matrix - ordinal matrix
 //  o Vector - vector (row or column)
 //  o SquareMatrix - square matrix (can be inverted)
 //  o SymmetricMatrix - symmetric matrix (reduces memory storage)
 //  o TriangleMatrix - left and right triangle matrix
 //  o DiagonalMatrix - diagonal matrix, the special kind of matrix
 //  o IdentityMatrix - Identity matrix (does not require memory storage)
 //  o BandMatrix - special sort of sparce matrix
 //  o GrowMatrix - matrix that can change its size(dimensions) without reallocation memory storage
 //  o GrowVector - vector (row or column) that can change its size without reallocation
 //  o SymmetricGrowMatrix - the special type of GrowMatrix
 //  As this is template package you can use it with any type of objects.
 //  You can derive any object to enhance its functionality and etc.
 //
 //   /Started: Oct 1997/
 /////

/////
 // Base Matrix class.
 //  Description:
 //   *Matrix* is two dimmension array of values
 //          | a11   a12 ... a1n |
 //      A = | a21   a22 ... a2n |
 //          | ...   ... ... ... |
 //          | am1   am2 ... amn |
 //   A matrix defines its *dimension* m x n, i.e. multiplexion of the number of its rows (n) and
 //   the number of its columns (m).
 //  Summury:   It represents ordinary matrix with necessary rows and columns.
 //   The follow example define matrix A with 5 rows and 3 columns.
 //   The A matrix store double values.
 //   Matrix<double> A(5,3)
 //   One can simple manipulate with matrix elements via () operator.
 //   The follow example initialize first column of the A matrix
 //   A(1,1)=1; A(1,2)=2; A(1,3)
 //   Note: Indexes in all matrix operation start with 1 (as you expect in mathematics)
 //         not with 0 (as you expect in C programming). So first element of a matrix is accessed as (1,1).
 //
 //   As the package defines some operators for Matrix classes you can carry out complex matrix operation
 //   in the simple case as showed on follow example.
 //   Matrix<float> a(3,3),b(3,3),c(3,3);
 //   c(3,3)=a+b;
 //   c+=(b//a);
 //   cout << c.Transpose();
 //
 //   All operation with matrixes can be divided into some groups:
 //      - *construction*. Allows to create a matrix from another.
 //          Matrix<float> a(2,3);
 //          Matrix<float> b(a);
 //      - *size operation*. Allows to retrieve and change matrix dimensions.
 //          Matrix<float> a(2,3);
 //          int columns=a.GetColumns();
 //          a.SetDimensions(5,4);
 //      - *access operation*. Allows to get and set matrix elements.
 //          for(int row=1;row<=a.GetRows();row++)
 //              for(int column=1;column<=a.GetColumns();column++) a(row,column)=1;
 //          b(1,1)=a(1,2);
 //      - *mathematical operation*. Allows to sum, substruct, multiply two matrixes and sum a matrix with scalal.
 //                                  Addition matrix operations (transposition) is also provided.
 //          Matrix<float> c(2,3);
 //          c=a+b;
 //          Matrix<float> d(c*a.Transpose());
 //          cout << d;
 // {groups:members,constdesct,size,access,*,private}
/////
template<class MatrixType> class Matrix
{
protected:
    // {group:members}Number of rows and columns in matrix
	int m_rows,m_columns;
    // {group:members}Data storage. Information is stored by rows.
	MatrixType* m_matrix;
public:
    /////
     // {group:constdest}
     // Empty Default constructor for derived classes.
     // It does not allocate memory for value storage.
     // To alloc memory and make real matrix creation you have to call Matrix::ResetDimensions function
     // with necessary number of rows and columns.
    /////
	Matrix()
	{
		m_rows=m_columns=0;
		m_matrix=NULL;
	}
    /////
     // {group:constdest}
     // Desctiptions:
     // Creates matrix with necessary number of rows/columns.
     // Allocate memory to store matrix values and initialize them.
     // Parameters:
     // rows - number of rows in matrix
     // columns - number of columns in matrix
     // initial_data - initial data for the storage (values are stored by rows)
     // Note: if initial_data parameters is set to NULL all values are initialized by 0 value.
     //       (memcpy is called to inialize, so it's fast enought)
    ///
    Matrix(int rows,int columns,const MatrixType* initial_data=NULL)
	{
		assert(rows>=0);
		assert(columns>=0);
		m_matrix=NULL;
		_copy(rows,columns,initial_data);
	}

    /////
     // {group:constdest}
     // Copy constructor
     // Thank to it you can use such operators:
     // Matrix<double> a(2,3);
     // Matrix<double> b(a);
     // Parameters:
     // initial_matrix - matrix with data to initiate
    /////
	Matrix(const Matrix<MatrixType>& initial_matrix)
	{
		m_matrix=NULL;
		_copy(initial_matrix.GetRows(),initial_matrix.GetColumns(),initial_matrix.GetData());
	}

public: /////
         // {group:constdest}
         // Destructor
         // Description:
         // Frees alloced memory, if any.
         /////
	~Matrix()
	{
		if(m_matrix) { delete[] m_matrix; m_matrix=NULL; } // clean up
	}
private: /////
          // {group:private}
          // Private function for matrix initialization
          // Description:
          // Reallocs memory for matrix values.
          // Parameters:
          // rows,column - number of rows/columns to allock memory (rows//columns)
          // initial_data - pointer to data to initiate new alloced storage
          /////
    void _copy(int rows,int columns,const MatrixType* initial_data)
	{
		assert(rows>0);
		assert(columns>0);
		m_rows=rows;
		m_columns=columns;
        int matrix_size=(m_columns)*(m_rows);
		if(m_matrix!=NULL) { delete m_matrix; m_matrix=NULL; }
		m_matrix=new MatrixType[matrix_size];
		assert(m_matrix);
        if(initial_data!=NULL) memcpy(m_matrix,initial_data,matrix_size*sizeof(MatrixType));
        else                   memset(m_matrix,0,matrix_size*sizeof(MatrixType));
	}

public:
    ///// Size manipulation functions. ///
    /////
     // {group:size}
     //  Returns number of rows in matrix.
     //  Returns:
     //  Returns number of rows in matrix.
     /////
	int GetRows() const { return m_rows; }

    /////
     //  {group:size}
     //  Returns number of columns in matrix.
     //  Returns:
     //  Returns number of columns in matrix.
     /////
	int GetColumns() const { return m_columns;  }

    /////
     // {group:size}
     // Description:
     // Changes the matrix size and reallocks the matrix memory storage.
     // Note: The matrix data will be lost.
     // Parameters:
     //  rows - new number of rows
     //  columns - new number of columns
     //  initial_data - pointer to initial data storage (it must have the same size)
     // Note: if new rows and columns are the same reallocation does not call.
    ///
    virtual void ResetDimensions(int rows,int columns,const MatrixType* initial_data=NULL)
	{
		_copy(rows,columns,initial_data);
	}

public:
    ///// Access methods. ///
    /////
     // {group:access}
     // Description:
     // Returns matrix value (element) at given row,column
     // Thank it, one can write c=A(2,3) to get element at 2'nd row and 3'rd column
     // Parameters:
     // row,column - given row and column to access the element
     // Note: row and columns are counted with 1 (0 is wrong number for column or row)
     /////
	virtual const MatrixType operator() (int row,int column) const
	{
		row--;
		column--;
		assert((row>=0)&&(row<m_rows)&&(column>=0)&&(column<m_columns));
		return m_matrix[row*m_columns+column];
	}

    /////
     // {group:access}
     // Description:
     // Set matrix value (element) at given row,column
     // Thank it, one can write A(2,3)=5 to set element at 2'nd row and 3'rd column to 5
     // Parameters:
     // row,column - given row and column to set
     // Note: row and columns are counted with 1 (0 is wrong number for column or row)
     /////
	virtual MatrixType& operator() (int row,int column)
	{
		row--;
		column--;
		assert((row>=0)&&(row<m_rows)&&(column>=0)&&(column<m_columns));
		return m_matrix[row*m_columns+column];
	}

    /////
     // {group:access}
     // Description:
     // Enhanced access routine.
     // Returns pointer to data storage of matrix.
     // Note: values in matrix memory storage are stored by columns. That is mean
     // - GetData()[0]=A(1,1)
     // - GetData()[1]=A(1,2)
     // - GetData()[2]=A(1,3)
     // ...
     /////
	const MatrixType* GetData() const { return m_matrix; }

    ///// Special matrix operations. ///

    /////
     // {group:operations}
     // Description:
     // Function for matrix calculation of the transposed matrix.
     // //Transposed matrix// is matrix which columns correspond to rows given matrix.
     // Transposition of a matrix A(m,n) creates matrix AT(m,n) there AT(i,j)=A(j,i).
     //
     // Function can be used:
     // Matrix<double> a(2,3);
     // a(1,1)=a(1,2)=a(1,3)=2;
     // a(2,1)=a(2,2)=a(1,3)=1;
     // cout << "transposed matrix\n" << a.Transponame() << "\nnormal matrix\n" << a;
     //
     // Returns:
     // Returns new transposed matrix.
    ///
	virtual Matrix<MatrixType> Transpose() const
	{
		assert(m_matrix);
		Matrix<MatrixType> trmatrix(m_columns,m_rows);
		for(int column=1;column<=m_columns;column++)
			for(int row=1;row<=m_rows;row++)  trmatrix(column,row)=(*this)(row,column);
		return trmatrix;
	}

    /////
     // {group:operations}
     // Transposes matrix and stores in itself.
     // For transposition see Matrix::Transpose() function.
     // Note: this function changes its matrix.
     /////
	virtual void TransposeItself()
	{
		int rows=m_columns, columns=m_rows;
		Matrix<MatrixType> trmatrix(columns,rows);
		for(int column=1;column<=m_columns;column++)
			for(int row=1;row<=m_rows;row++) trmatrix(column,row)=(*this)(row,column);
		int matrix_size=m_columns*m_rows;
		memcpy(m_matrix,trmatrix.GetData(),matrix_size*sizeof(MatrixType));
		int swap=m_rows; m_rows=m_columns; m_columns=swap;
	}

	/////////////////////////////////////////////////////////////////////
	// Matrix Operators
	// Operator overloaded using a member function

    /////
     //  Copping of a matrix.
     //  Allows to write such sentences:
     //  Matrix<double> a(3,3);
     //  b=a;
     /////
	Matrix<MatrixType>& operator=(const Matrix<MatrixType>& matrix)
	{
		_copy(matrix.GetRows(),matrix.GetColumns(),matrix.GetData());
		return *this;
	}

    /////////
    //  Matrix Summation Operator.
    // Sums two matrixes.
    // Returns:
    // New matrix which each element equals sum of correspondence elements of operators.
    // Example:
    //  Matrix<double> a(3,3),b(3,3),c(3,3);
    //  c=a+b;
	friend Matrix<MatrixType> operator+( const Matrix<MatrixType> &first, const Matrix<MatrixType> &second )
	{
		assert((first.GetRows()==second.GetRows())&&(first.GetColumns()==second.GetColumns()));
		int rows=first.GetRows(),columns=first.GetColumns();
		Matrix<MatrixType> sum(rows,columns);
		for(int column=1;column<=columns;column++)
			for(int row=1;row<=rows;row++) sum(row,column)=first(row,column)+second(row,column);
		return sum;
	}

    /////////
    // Addition Constant to Matrix Operator.
    // Adds the constant to every element of the matrix.
    // Returns:
    // New matrix which each element equals sum of correspondance previous element and the scalar.
    // Example:
    //  Matrix<double> a(3,3),b(3,3);
    //  b=a+2;
	friend Matrix<MatrixType> operator+( const Matrix<MatrixType> &matrix, const MatrixType constant )
	{
		int rows=matrix.GetRows(),columns=matrix.GetColumns();
		Matrix<MatrixType> sum(rows,columns);
		for(int column=1;column<=columns;column++)
			for(int row=1;row<=rows;row++) sum(row,column)=matrix(row,column)+constant;
		return sum;
	}

    /////////
    // Addition Constant to Matrix Operator. Second variant.
    // See previous operator description for more details.
    // Example:
    //  Matrix<double> a(3,3),b(3,3);
    //  b=2+a;
	friend Matrix<MatrixType> operator+( const MatrixType constant, const Matrix<MatrixType> &matrix)
	{
		int rows=matrix.GetRows(),columns=matrix.GetColumns();
		Matrix<MatrixType> sum(rows,columns);
		for(int column=1;column<=columns;column++)
			for(int row=1;row<=rows;row++)  sum(row,column)=matrix(row,column)+constant;
		return sum;
	}

    /////////
    //  To Matrix Summation Operator.
    // Adds another matrix to this one.
    // Returns:
    // This matrix.
    // Note: This operator change the matrix.
    // Example:
    //  Matrix<double> a(3,3),b(3,3);
    //  a+=b;
	Matrix<MatrixType>& operator+=(const Matrix<MatrixType>& other)
	{
 		assert((other.GetRows()==m_columns)&&(other.GetColumns()==m_rows));
		for(int column=1;column<=m_columns;column++)
			for(int row=1;row<=m_rows;row++) (*this)(row,column)+=other(row,column);
		return (*this);
	}

    /////////
    //  To Matrix Summation Operator.
    // Adds constant to this matrix.
    // Returns:
    // This matrix.
    // Note: This operator change the matrix.
    // Example:
    //  Matrix<double> a(3,3);
    //  a+=3;
	Matrix<MatrixType>& operator+=(const MatrixType constant)
	{
		for(int column=1;column<=m_columns;column++)
			for(int row=1;row<=m_rows;row++) (*this)(row,column)+=constant;
		return (*this);
	}

    /////////
    //  Matrix Substraction Operator.
    // Calculate substruct matrix by two given matrixes.
    // Returns:
    // New matrix which each element equals substruction of correspondence elements of operators.
    // Example:
    //  Matrix<double> a(3,3),b(3,3),c(3,3);
    //  c=a-b;
	friend Matrix<MatrixType> operator-( const Matrix<MatrixType> &first, const Matrix<MatrixType> &second )
	{
		assert((first.GetRows()==second.GetRows())&&(first.GetColumns()==second.GetColumns()));
		int rows=first.GetRows(),columns=first.GetColumns();
		Matrix<MatrixType> sub(rows,columns);
		for(int column=1;column<=columns;column++)
			for(int row=1;row<=rows;row++) sub(row,column)=first(row,column)-second(row,column);
		return sub;
	}

    /////////
    // Constant Substruction Matrix Operator.
    // Sunstruct the constant from every element of the matrix.
    // Returns:
    // New matrix which each element equals substruction of correspondance previous element and the scalar.
    // Example:
    //  Matrix<double> a(3,3),b(3,3);
    //  b=a-2;
    // Note: we can't substrcat a matrix from a constant b=(2-a)
	friend Matrix<MatrixType> operator-( const Matrix<MatrixType> &matrix, const MatrixType constant )
	{
		int rows=matrix.GetRows(),columns=matrix.GetColumns();
		Matrix<MatrixType> sub(rows,columns);
		for(int column=1;column<=columns;column++)
			for(int row=1;row<=rows;row++) sub(row,column)=matrix(row,column)-constant;
		return sub;
	}
	// we can't substrcat a matrix from a constant

    /////////
    // Substruct Matrix Operator.
    // Substruct given matrix from this matrix.
    // Returns:
    // This matrix.
    // Note: This operator change the matrix.
    // Example:
    //  Matrix<double> a(3,3);
    //  a-=3;
	Matrix<MatrixType>& operator-=(const Matrix<MatrixType>& other)
	{
 		assert((other.GetRows()==m_rows)&&(other.GetColumns()==m_columns));
		for(int column=1;column<=m_columns;column++)
			for(int row=1;row<=m_rows;row++) (*this)(row,column)-=other(row,column);
		return (*this);
	}

    /////////
    //  Constant Substruction Operator from This Matrix.
    // Substructs constant from this matrix.
    // Returns:
    // This matrix.
    // Note: This operator change the matrix.
    // Example:
    //  Matrix<double> a(3,3);
    //  a-=3;
	Matrix<MatrixType>& operator-=(const MatrixType constant)
	{
		for(int column=1;column<=m_columns;column++)
			for(int row=1;row<=m_rows;row++) (*this)(row,column)-=constant;
		return (*this);
	}

    /////////
    // Constant Multiplexion Matrix Operator.
    // Multiplexes every element of the matrix to given constant.
    // Returns:
    // New matrix which each element equals multiplexion of correspondance previous element and the scalar.
    // Example:
    //  Matrix<double> a(3,3),b(3,3);
    //  b=a*2;
	friend Matrix<MatrixType> operator*( const Matrix<MatrixType> &matrix, const MatrixType constant)
	{
		int rows=matrix.GetRows(),columns=matrix.GetColumns();
		Matrix<MatrixType> mul(rows,columns);
		for(int column=1;column<=columns;column++)
			for(int row=1;row<=rows;row++) mul(row,column)=matrix(row,column)*constant;
		return mul;
	}

    /////////
    // Addition Constant Multiplexion Matrix Operator. Second variant.
    // See previous operator description for more details.
    // Example:
    //  Matrix<double> a(3,3),b(3,3);
    //  b=2*a;
	friend Matrix<MatrixType> operator*(const MatrixType constant,const Matrix<MatrixType> &matrix)
	{
		int rows=matrix.GetRows(),columns=matrix.GetColumns();
		Matrix<MatrixType> mul(rows,columns);
		for(int column=1;column<=columns;column++)
			for(int row=1;row<=rows;row++) mul(row,column)=matrix(row,column)*constant;
		return mul;
	}

    /////////
    //  Constant Multiplexion Operator for This Matrix.
    // Multiplex every element of the matrix to given constant.
    // Returns:
    // This matrix.
    // Note: This operator change the matrix.
    // Example:
    //  Matrix<double> a(3,3);
    //  a*=2;
	Matrix<MatrixType>& operator*=(const MatrixType constant)
	{
		for(int column=1;column<=m_columns;column++)
			for(int row=1;row<=m_rows;row++) (*this)(row,column)*=constant;
		return (*this);
	}

    /////////
    // Summury:
    // Matrix Multiplexion Operator.
    // Calculates multiplexion of two matrixes.
    // Description:
    // *Multiplexion* of two matrixes A with dimension m x n and B with dimension n x l is calculated
    // by formula:
    // C(k,j)=Sum(A(k,i)*B(i,j))|i=1..n
    // there j=1,2,...,l    k=1,2,...,m
    // Resulting matrix C has dimension m x l.
    // Returns:
    // New matrix which equals multiplexion of given matrix.
    // Example:
    //  Matrix<double> a(4,5),b(5,3),c(4,3);
    //  a(1,1)=1; a(1,2)=2; a(1,3)=3; a(1,4)=4; a(1,5)=5;
    //  a(2,1)=6; a(2,2)=7; a(2,3)=8; a(2,4)=9; a(2,5)=1;
    //  a(3,1)=2; a(3,2)=3; a(3,3)=4; a(3,4)=5; a(3,5)=6;
    //  a(4,1)=7; a(4,2)=8; a(4,3)=9; a(4,4)=1; a(4,5)=2;
    //
    //  b(1,1)=1; b(1,2)=2; b(1,3)=3;
    //  b(2,1)=1; b(2,2)=2; b(2,3)=3;
    //  b(3,1)=1; b(3,2)=2; b(3,3)=3;
    //  b(4,1)=1; b(4,2)=2; b(4,3)=3;
    //  b(5,1)=1; b(5,2)=2; b(5,3)=3;
    //
    //  c=a*b;
    //  cout << c;
    //
    //  Prints
    //  4 3
    //  15 30 45
    //  31 62 93
    //  20 40 60
    //  27 54 81
	friend Matrix<MatrixType> operator*(const Matrix<MatrixType>& first,const Matrix<MatrixType>& second)
	{
		int M=first.GetRows(), N=first.GetColumns(), N1=second.GetRows(), L=second.GetColumns();
		assert(N==N1);
		Matrix<MatrixType> mul(M,L);
		for(int i=1;i<=M;i++)
			for(int j=1;j<=L;j++)
			{
				MatrixType s=0;
				for(int k=1;k<=N;k++) s+=first(i,k)*second(k,j);
				mul(i,j)=s;
			}
		return mul;
	}
	// one can't mul matrix with assigment (operator *=) , so such mul produces another-size matrix


	/** Stream operation **/
	/* Prints out the matrix*/
	//void TuneUpOut(initialForm,FormValue,DelimValue,DelimLine)
	//{
	//
	//}

	static ostream& InitialForm(ostream& os)
	{
		os.flags( ios::fixed );
		//os << ios::showpoint << /*ios::scientific <<*/ ios::fixed;
		return os;
	}

	static ostream& FormValue(ostream& os) // default value formation
	{
		//os.width(16);
		//os.precision(6);
		return os;
	}

	static ostream& DelimValue(ostream& os) // default value formation
	{
		os << " ";
		return os;
	}

	static ostream& DelimLine(ostream& os) // default value formation
	{
		os << endl;
		return os;
	}

    /////
     // Output Operator for Matrix
     // Outputs matrix into stream.
     // Example:
     // Matrix<double> a(3,3);
     // cout << a;
     /////
	friend ostream& operator<< ( ostream& os,const Matrix<MatrixType>& matrix )
	{
		int rows=matrix.GetRows(),  columns=matrix.GetColumns();
		os << rows << Matrix<MatrixType>::DelimValue << columns << Matrix<MatrixType>::DelimLine;
		os << Matrix<MatrixType>::InitialForm;
		for(int row=1;row<=rows;row++)
		{
			for(int column=1;column<=columns;column++)
			{
				os << Matrix<MatrixType>::FormValue << matrix(row,column) << Matrix<MatrixType>::DelimValue;
			}
			os << Matrix<MatrixType>::DelimLine;
		}
		return os;
	}

    /////
     // Input Operator for Matrix
     // Inputs the matrix from stream
     // Matrix<float> a;
     // cin >> a;
     /////
	friend istream& operator>> ( istream& is,Matrix<MatrixType>& matrix )
	{
		int rows,columns;
		is >> rows >> columns;
		if(matrix.GetRows()!=rows || matrix.GetColumns()!=columns) // realloc memory
		{
			matrix.ResetDimensions(rows,columns);
		}
		for(int row=1;row<=rows;row++)
		{
			for(int column=1;column<=columns;column++)
			{
				is >> matrix(row,column);
			}
		}
		return is;
	}
};


///
////////////////////////////////////////////////////
// Common matrix types.
////////////////////////////////////////////////////
/////

/////
// Vector (column or row).
// Vector is matrix which one dimension equals to 1.
/////
template<class MatrixType> class Vector : public Matrix<MatrixType>
{
protected:
    ///// If true this is row otherwise this is column ///
	bool m_bRow;
public:
    /////
    //  Constructor.
    //  Parameters:
    //   N - number of vector elements
    //   bRow - indicates type of vector (row if true or column if false)
    //   initial_data - initial data for the vector
    /////
	Vector(bool bRow=false) : Matrix<MatrixType>() { m_bRow=bRow; }
	Vector(int N, bool bRow=true, const MatrixType* initial_data=NULL)
		: Matrix<MatrixType>(N,1,initial_data) // allock memory for data
	{
		m_bRow=bRow;
		if(m_bRow)	{ m_columns=N;	m_rows=1; }
		else		{ m_rows=N;		m_columns=1; }
	}

    ///// Transposition for row is its conversion to column
    //   and transposition for column is its conversion to row
    ///
	virtual Matrix<MatrixType> Transpose() const
	{
		if(m_bRow) { return Vector<MatrixType>(m_columns,!m_bRow,m_matrix); }
		else	   { return Vector<MatrixType>(m_rows,!m_bRow,m_matrix);	}
	}

    ///// Transposition for row is its conversion to column
    //   and transposition for column is its conversion to row
    ///
	virtual void TransposeItself()
	{
		m_bRow=!m_bRow;
		// swap columns<->rows
		int swap=m_columns; m_columns=m_rows; m_rows=swap;
	}

	int GetSize() const
	{
		if(m_bRow) return m_columns;
		else	   return m_rows;
	}

    ///// Fast access operators.
    //   It counts from 1 (not from 0)
    ///
	MatrixType operator() (int i) const // get operator
	{
		i--;
		assert(i>=0);
		assert(i<GetSize());
		return m_matrix[i];
	}
	MatrixType& operator() (int i) // set operator
	{
		i--;
		assert(i>=0);
		assert(i<GetSize());
		return (m_matrix[i]);
	}
	bool IsRow() { return m_bRow; }

	void ResetDimensions(int N,const MatrixType *initial_data=NULL)
	{
		Matrix<MatrixType>::ResetDimensions(N,N,initial_data);
	}

    ///// Outputs vector into stream. ///
/*
	friend ostream& operator<< ( ostream& os,const Vector<MatrixType>& vector )
	{
		int N;
		if(vector.IsRow()) N=vector.GetRows() else N=GetColumns();
		os << N << Matrix<MatrixType>::DelimLine;
		os << Matrix<MatrixType>::InitialForm;
		for(int i=1;i<=N;i++)
		{
				os << Matrix<MatrixType>::FormValue << vector(i);
				if(vector.IsRow())	os << Matrix<MatrixType>::DelimValue;
				else				os << Matrix<MatrixType>::DelimLine;
		}
		return os;
	}
*/
    ///// Inputs the matrix from stream ///
/*
	friend istream& operator>> ( istream& is,Vector<MatrixType>& matrix )
	{
		int rows,columns;
		is >> rows >> columns;
		if(matrix.GetRows()!=rows || matrix.GetColumns()!=columns) // realloc memory
		{
			matrix.ResetDimensions(rows,columns);
		}
		for(int row=1;row<=rows;row++)
		{
			for(int column=1;column<=columns;column++)
			{
				is >> matrix(row,column);
			}
		}
		return is;
	}
*/
};

/////
//   Square Matrix.
//   Square Matrix is matrix which number of rows equals to its number of columns.
//   Square Matrix can be quick transformed.
//   Square Matrix can be Inverseed.
/////
template<class MatrixType> class SquareMatrix : public Matrix<MatrixType>
{
public:
    ///// Constructors. Square matrix is ordinal matrix.
    //   The difference is it has one parameter for dimensions.
    ///
	SquareMatrix() : Matrix<MatrixType>() {}

	SquareMatrix(int N,MatrixType* initial_data=NULL)
		: Matrix<MatrixType>(N,N,initial_data) {}

    /////
    // Square matrix can be transposed without aux matrix.
    ///
	virtual void TransposeItself()
	{
		for(int row=0;row<m_rows;row++)
			for(int column=row+1;column<m_columns;column++)
			{
				MatrixType c=(*this)(row,column);
				(*this)(row,column)=(*this)(column,row);
				(*this)(column,row)=c;
			}
		// transposed matrix is placed in original matrix place
	}

    /////
    //   Decomposite square matrix into two triangle matrixes.
    //   This function is used for matrix inversion and resolution of equation system.
    /////
	virtual bool Decomposite(SquareMatrix<MatrixType>& B,
							 SquareMatrix<MatrixType>& C)
	{
		// Step 1. Represents matrix A as two triangle matrixes B and C
		//		   by Holetsky decomposition.
		//		( B is low triangle matrix and C is up triangle matrix with identity diagonal)
		int N=m_rows;
		for(int l=1;l<=N;l++) // pass on rows for B and on columns for C
		{
			for(int i=l;i<=N;i++)
			{
				MatrixType sumBC1=0;
				for(int k=1;k<l;k++)
					sumBC1+=(B(i,k)*C(k,l));
				MatrixType v=(*this)(i,l)-sumBC1;
				B(i,l)=v;
			}
			C(l,l)=1;
			for(int j=l+1;j<=N;j++)
			{
				MatrixType sumBC2=0;
				for(int k=1;k<l;k++)
					sumBC2+=( B(l,k)*C(k,j) );
				if(B(l,l)==0) return false; //assert(B(l,l)!=0);
				MatrixType v=( (*this)(l,j)-sumBC2 )/B(l,l);
				C(l,j)=v;
			}
		}
		return true;
	}

	virtual bool DecompositeItself()
	{
		return Decomposite(*this,*this);
	}

    /////
    //   Square matrix can be Inverseed with Holetchky's Method
    //   optional @param bandSize allows to create band matrix
    ///
	virtual bool InverseItself(int bandSize=0)
	{
		switch(m_rows)
		{
		case 1: // 1x1 matrix
			{
				if(m_matrix[0]==0) return false;
				m_matrix[0]=1/m_matrix[0];
				return true;
			}
		case 2: // 2x2 matrix
			{
				MatrixType e=(*this)(2,1)*(*this)(1,2);
				MatrixType f=(*this)(1,1);
							e=(*this)(2,2)*f-e;
				if(e==0) return false;
				(*this)(1,1)=(*this)(2,2)/e;
				(*this)(2,2)=f/e;
				(*this)(2,1)=-(*this)(2,1)/e;
				(*this)(1,2)=-(*this)(1,2)/e;
				return true;
			}
/*
		case 3: // 3x3 matrix
			{
				for(int k=1;k<3;k++)
				{
					if((*this)(1,1)==0) return false;
					MatrixType a=(*this)(2,1)/(*this)(1,1);
					MatrixType b=-a;
					MatrixType c=(*this)(2,2)-a*(*this)(1,2);
					MatrixType d=(*this)(2,3)-a*(*this)(1,3);
					a=(*this)(3,1)/(*this)(1,1);
					(*this)(2,3)=-a;
					(*this)(2,1)=(*this)(3,2)-a*(*this)(1,2);
					(*this)(2,2)=(*this)(3,3)-a*(*this)(1,3);
					(*this)(3,1)=(*this)(1,2)/(*this)(1,1);
					(*this)(3,2)=(*this)(1,3)/(*this)(1,1);
					(*this)(3,3)=1/(*this)(1,1);
					(*this)(1,1)=c;
					(*this)(1,2)=d;
					(*this)(1,3)=b;
				}
				return true;
			}
*/
		default: // any size matrix inversion is not implemented yet
			{
				// Matrix Inversion by triangle decomposition
				int N=GetRows();
				TriangleMatrix<MatrixType> T1(N,true),T2(N,false);
				if(!Decomposite(T1,T2)) return false;
				T1.InverseItself();
				T2.InverseItself();
				// Muls two inverted matrixes to invert itself ( if A=T1*T2 then A(-1)=T2(-1)*T1(-1) )
				for(int i=1;i<=N;i++)
					for(int j=1;j<=N;j++)
				{
					MatrixType s=0;
					int maxij=(i>j) ? i : j;
					for(int k=maxij;k<=N;k++) s+=T2(i,k)*T1(k,j);
					(*this)(i,j)=s;
				}
				return true;
			}
		}
		return false;
	}

	SquareMatrix<MatrixType> Inverse()
	{
		SquareMatrix<MatrixType> M(m_rows,m_matrix);
		M.InverseItself();
		return M;
	}
};

/////
//   Symmetric Matrix.
//   Symmetric Matrix is matrix which one half is simmetric to another half.
//   So we can store just half past (upper) of the matrix data.
///
template<class MatrixType> class SymmetricMatrix : public SquareMatrix<MatrixType>
{
protected:
    ///// size of symmetric matrix ///
	int m_matrix_size;
public:
    ///// Constructor. Symmetric matrix is kind of square matrix.
    ///
	SymmetricMatrix() { Matrix<MatrixType>(); }
	SymmetricMatrix(int N,const MatrixType* initial_data=NULL)
		: SquareMatrix<MatrixType>() // initial creation -> don't alloc memory
	{
		_copyS(N,initial_data);
	}

    ///// Copy Constructor ///
	SymmetricMatrix(const SymmetricMatrix& init) //: SquareMatrix<MatrixType>()
	{
		_copyS(init.GetRows(),init.GetData());
	}

    ///// Redefine the access operators for new data store model. ///
	const MatrixType operator() (int row, int column) const // get operator
	{
		assert((row>=1)&&(row<=m_rows)&&(column>=1)&&(column<=m_columns));
		// we store only up triangle of the matrix
		// so if one requires data from low triangle then simple swap row and column.
		if(row>column) { int swap=row; row=column; column=swap; }
		// data are stored with division on columns
		int index=(column*column-column)/2+row-1;
		return m_matrix[index];
	}
	MatrixType& operator() (int row, int column) // set operator
	{
		assert((row>=1)&&(row<=m_rows)&&(column>=1)&&(column<=m_columns));
		// we store only up triangle of the matrix
		// so if one requires data from low triangle then simple swap row and column.
		if(row>column) { int swap=row; row=column; column=swap; }
		// data are stored with division on columns
		int index=(column*column-column)/2+row-1;
		return m_matrix[index];
	}

    ///// Redefine dimension change routine for new data store model. ///
	virtual void ResetDimensions(int rows,int columns,const MatrixType* initial_data=NULL) // realloc matrix
	{
		assert(rows==columns); // symmetric matrix demands Rows==Columns
		_copyS(rows,initial_data);
	}

    ///// Overdrive operators to speed up specific matrix operation. ///
	friend SymmetricMatrix<MatrixType> operator+( const SymmetricMatrix<MatrixType> &first, const SymmetricMatrix<MatrixType> &second)
	{
		assert((first.GetRows()==second.GetRows())&&(first.GetColumns()==second.GetColumns()));
		int columns=first.GetColumns();
		SymmetricMatrix<MatrixType> sum(columns,first.GetData());
		MatrixType* pData1=(MatrixType*)sum.GetData();
		const MatrixType* pData2=second.GetData();
		int matrix_size=(columns)*(columns+1)/2;
		for(int index=0;index<matrix_size;index++) { pData1[index]+=pData2[index]; } // low level addition
		// high level addition
		//for(int j=0;j<columns;j++)
		//	for(int i=j;i<columns;i++) sum.SetIJ(i,j,first.(i,j)+second.(i,j) );
		return sum;
	}

	SymmetricMatrix<MatrixType>& operator+=(const SymmetricMatrix<MatrixType>& other)
	{
 		assert((other.GetRows()==m_columns)&&(other.GetColumns()==m_rows));
		const MatrixType* pData2=other.GetData();
		for(int index=0;index<m_matrix_size;index++) { m_matrix[index]+=pData2[index]; } // low level addition
		// high level addition
		//for(int j=0;j<m_rows;j++)
		//	for(int i=j;i<m_columns;i++) SetIJ(i,j,(i,j)+other.(i,j) );
		return (*this);
	}

	// Substraction
	friend SymmetricMatrix<MatrixType> operator-( const SymmetricMatrix<MatrixType> &first, const SymmetricMatrix<MatrixType> &second)
	{
		assert((first.GetRows()==second.GetRows())&&(first.GetColumns()==second.GetColumns()));
		int columns=first.GetColumns();
		SymmetricMatrix<MatrixType> sub(columns,first.GetData());
		MatrixType* pData1=(MatrixType*)sub.GetData();
		const MatrixType* pData2=second.GetData();
		int matrix_size=(columns)*(columns+1)/2;
		for(int index=0;index<matrix_size;index++) { pData1[index]-=pData2[index]; } // low level substraction
		// high level substraction
		//for(int j=0;j<columns;j++)
		//	for(int i=j;i<columns;i++) sub.SetIJ(i,j,first.(i,j)-second.(i,j) );
		return sub;
	}

	SymmetricMatrix<MatrixType>& operator-=( const SymmetricMatrix<MatrixType> &matrix )
	{
		assert((matrix.GetRows()==GetRows())&&(matrix.GetColumns()==GetColumns()));
		const MatrixType* pData2=matrix.GetData();
		for(int index=0;index<m_matrix_size;index++) { m_matrix[index]-=pData2[index]; } // low level substraction
		// high level substraction
		//for(int j=0;j<m_rows;j++)
		//	for(int i=j;i<m_columns;i++) SetIJ(i,j,(i,j)-matrix.(i,j) );
		return (*this);
	}

	// Muls a to scalar
	friend SymmetricMatrix<MatrixType> operator*( const SymmetricMatrix<MatrixType> &matrix, const MatrixType scalar)
	{
		int columns=matrix.GetColumns();
		SymmetricMatrix<MatrixType> mul(columns,matrix.GetData());
		MatrixType* pData=(MatrixType*)mul.GetData();
		int matrix_size=(columns)*(columns+1)/2;
		for(int i=0;i<matrix_size;i++) pData[i]*=scalar; // low level mul
		// high level
		//for(int j=0;j<columns;j++)
		//	for(int i=j;i<columns;i++) mul.SetIJ(i,j,matrix.(i,j)*scalar);
		return mul;
	}

	friend SymmetricMatrix<MatrixType> operator*( const MatrixType scalar,const SymmetricMatrix<MatrixType> &matrix)
	{
		int columns=matrix.GetColumns();
		SymmetricMatrix<MatrixType> mul(columns,matrix.GetData());
		MatrixType* pData=(MatrixType*)mul.GetData();
		int matrix_size=(columns)*(columns+1)/2;
		for(int i=0;i<matrix_size;i++) pData[i]*=scalar; // low level mul
		//TriangleMatrix<MatrixType> mul(columns);
		//for(int j=0;j<columns;j++)
		//	for(int i=j;i<columns;i++) mul.SetIJ(i,j,matrix.(i,j)*scalar);
		return mul;
	}

	SymmetricMatrix<MatrixType>& operator*=(const MatrixType scalar)
	{
		for(int i=0;i<m_matrix_size;i++) m_matrix[i]*=scalar; // low level mul
		//for(int j=0;j<m_rows;j++)
		//	for(int i=j;i<m_columns;i++) SetIJ(i,j,(i,j)*scalar );
		return (*this);
	}

    ///// Stream operation overloading.
    //   Symmetric matrix outs just its up triangle. ///
	friend ostream& operator<< ( ostream& os,const SymmetricMatrix<MatrixType>& matrix )
	{
		int N=matrix.GetRows();
		os << N << Matrix<MatrixType>::DelimLine;
		for(int row=1;row<=N;row++)
		{
			for(int i=1;i<row;i++) os << "         ";
			for(int column=row;column<=N;column++)
			{
				os << Matrix<MatrixType>::FormValue << matrix(row,column) << Matrix<MatrixType>::DelimValue;
			}
			os << Matrix<MatrixType>::DelimLine;
		}
		return os;
	}

    ///// Input symmetric matrix.
    //   Symmetric matrix is defined with its up triangle. ///
	friend istream& operator>> ( istream& is,SymmetricMatrix<MatrixType>& matrix )
	{
		int N;
		is >> N;
		if(N!=matrix.GetRows()) matrix.ResetDimensions(N,N); // realloc memory if any
		for(int row=1;row<N;row++)
		{
			for(int column=row;column<=N;column++)
			{
				is >> matrix(row,column);
			}
		}
		return is;
	}

	// Copy operator
	SymmetricMatrix<MatrixType>& operator=(const SymmetricMatrix<MatrixType>& matrix)
	{
		_copyS(matrix.GetRows(),matrix.GetData());
		return (*this);
	}

	void _copyS(int N,const MatrixType* initial_data)
	{
		if(m_matrix) { delete m_matrix; m_matrix=NULL; }
		assert(N);
		m_columns=N;
		m_rows=N;
		m_matrix_size=m_columns*(m_rows+1)/2; // size of triangle (half past) of matrix
		assert(m_matrix_size);
		m_matrix=new MatrixType[m_matrix_size];
		assert(m_matrix);
		if(initial_data==NULL) memset(m_matrix,0,m_matrix_size*sizeof(MatrixType));
		else				   memcpy(m_matrix,initial_data,m_matrix_size*sizeof(MatrixType));
	}

	// Step 1. Represents matrix A as two triangle matrixes T1 and T2 that
	//		    are simmetric each other.
	// iscomplex is array of flags to handle complex numbers
	virtual bool Decomposite(SquareMatrix<MatrixType>& T,Vector<int>& iscomplex)
	{
		// Step 1. Represents matrix A as two triangle matrixes T1 and T2 that
		//		    are simmetric each other.
		// iscomplex is array of flags to handle complex numbers
		int N=GetRows();
		for(int row=1;row<=N;row++)
		{
			// set complex status for given row
			MatrixType diagonalA=(*this)(row,row);
			// calculate diagonal element
			MatrixType sumTT=0;
			for(int k=1;k<row;k++)
			{
				if(iscomplex(k)) sumTT-=( T(k,row)*T(k,row) );
				else			 sumTT+=( T(k,row)*T(k,row) );
			}
			MatrixType diagonalT=diagonalA-sumTT;
			if(diagonalT==0) return false; // matrix can be calculated by sqrt method
			iscomplex(row)=(diagonalT<0);
			MatrixType Tii;
			if(iscomplex(row)) Tii=sqrt( -diagonalT );
			else			   Tii=sqrt( diagonalT );
			T(row,row)=Tii;
			// calculate other elements in current row
			for(int column=row+1;column<=m_columns;column++)
			{
				MatrixType sum=0;
				for(int k=1;k<row;k++)
				{
					if(iscomplex(k)) sum-=( T(k,row)*T(k,column) );
					else			 sum+=( T(k,row)*T(k,column) );
				}
				MatrixType v=((*this)(row,column)-sum)/Tii;
				if(iscomplex(row)) v=-v;
				T(row,column)=v;
			}
		}
		// End of step 1.
		// Triangle matrix T have been calculated
		return true;
	}

	virtual bool DecompositeItself(Vector<int>& iscomplex)
	{
		return Decomposite(*this,iscomplex);
	}

	// simmetric matrix can be Inverseed with SquareRoot Method
	SymmetricMatrix<MatrixType> Inverse()
	{
		SymmetricMatrix<MatrixType> rows(m_rows,m_matrix);
		rows.InverseItself();
		return rows;
	}

	virtual bool InverseItself(int bandSize=0)
	{
		if(m_rows<3) // must be if(m_rows<3)
		{
			return SquareMatrix<MatrixType>::InverseItself(bandSize);
		}
		// Matrix Inversion by triangle decomposition
		int N=GetRows();
		//SymmetricMatrix<MatrixType> T1(N,false); 
		TriangleMatrix<MatrixType> T1(N,false); // OR ERROR IS HERE
		Vector<int> iscomplex(N);
		if(!Decomposite(T1,iscomplex)) return false;
		T1.InverseItself();
		// Muls two inverted matrixes to invert itself ( if A=T1*T2 then A(-1)=T2(-1)*T1(-1) )
		for(int i=1;i<=N;i++)
			for(int j=i;j<=N;j++)
		{
			MatrixType s=0;
			int maxij=(i>j) ? i : j; 
			for(int k=maxij;k<=N;k++) 
				s+=T1(i,k)*T1(j,k);//s+=T2(i,k)*T1(k,j); /// ERROR IS HERE !!!
			(*this)(i,j)=s;
		}
		return true;
	}


};

/////
// Triangle Matrix is matrix one half of that (upper or low) is qual to 0.
// So we store just half past (upper) of matrix data.
// For low triangle matrix we simple swap row and column to get access as upper triangle.
//
// Triangle matrix can be Inverseed very fast (with O(n^2) complexity) and simple
///
template<class MatrixType> class TriangleMatrix : public SquareMatrix<MatrixType>
{
	bool m_bLow;
	int m_matrix_size; // ???
public:
	TriangleMatrix(int columns,bool bLow=true,const MatrixType* initial_data=NULL)
		: SquareMatrix<MatrixType>()
	{
		_copyTR(columns,bLow,initial_data);
	}

    ///// Copy Constructor ///
	TriangleMatrix(const TriangleMatrix& init) //: SquareMatrix<MatrixType>(1)
	{
		_copyTR(init.GetColumns(),init.m_bLow,init.GetData());
	}

    ///// Redefines the access operators for new data store model. ///
	const MatrixType operator() (int row, int column) const // get operator
	{
		assert((row>=1)&&(row<=m_rows)&&(column>=1)&&(column<=m_columns));
		// we store only up triangle of the matrix
		// or swap row and column to realize the access as for low triangle matrix
		if(m_bLow) { int swap=row; row=column; column=swap; }
		// so if one requires data from othet triangle then simple return 0
		if(column<row) return 0;
		// data are stored with division on columns
		int index=(column*column-column)/2+row-1;
		return m_matrix[index];
	}
	MatrixType& operator() (int row, int column) // set operator
	{
		assert((row>=1)&&(row<=m_rows)&&(column>=1)&&(column<=m_columns));
		// we store only up triangle of the matrix
		// or swap row and column to realize the access as for low triangle matrix
		if(m_bLow) { int swap=row; row=column; column=swap; }
		// so if one requires data from othet triangle then generate exception
		assert(row<=column);
		// data are stored with division on columns
		int index=(column*column-column)/2+row-1;
		return m_matrix[index];
	}

    ///// Redefines dimension change routine for new data store model. ///
	virtual void ResetDimensions(int rows,int columns,const MatrixType* initial_data=NULL) // realloc matrix
	{
		assert(rows==columns); // symmetric matrix demands Rows==Columns
		_copyTR(rows,m_bLow,initial_data);
	}

    ///// Determinates type of triangle of the matrix.
    //   Returns true if this is low triangle matrix and false if it is high triangle matrix.
    ///
	bool IsLow() const { return m_bLow; }

    ///// Overdrive operators to speed up specific matrix operation. ///
	friend TriangleMatrix<MatrixType> operator+( const TriangleMatrix<MatrixType> &first, const TriangleMatrix<MatrixType> &second)
	{
		assert( (first.GetRows()==second.GetRows())&&(first.GetColumns()==second.GetColumns())&&(first.IsLow()==second.IsLow()));
		int columns=first.GetColumns();
		TriangleMatrix<MatrixType> sum(columns,first.IsLow(),first.GetData());
		MatrixType* pData1=(MatrixType*)sum.GetData();
		const MatrixType* pData2=second.GetData();
		int matrix_size=(columns)*(columns+1)/2;
		for(int index=0;index<matrix_size;index++) { pData1[index]+=pData2[index]; } // low level addition
		// high level addition
		//for(int j=0;j<columns;j++)
		//	for(int i=j;i<columns;i++) sum.SetIJ(i,j,first.(i,j)+second.(i,j) );
		return sum;
	}

	TriangleMatrix<MatrixType>& operator+=(const TriangleMatrix<MatrixType>& other)
	{
 		assert( (other.GetRows()==m_columns)&&(other.GetColumns()==m_rows)&&(other.IsLow()==IsLow()) );
		const MatrixType* pData2=other.GetData();
		for(int index=0;index<m_matrix_size;index++) { m_matrix[index]+=pData2[index]; } // low level addition
		// high level addition
		//for(int j=0;j<m_rows;j++)
		//	for(int i=j;i<m_columns;i++) SetIJ(i,j,(i,j)+other.(i,j) );
		return (*this);
	}

	// Substraction
	friend TriangleMatrix<MatrixType> operator-( const TriangleMatrix<MatrixType> &first, const TriangleMatrix<MatrixType> &second)
	{
		assert( (first.GetRows()==second.GetRows())&&(first.GetColumns()==second.GetColumns())&&(first.IsLow()==second.IsLow()) );
		int columns=first.GetColumns();
		TriangleMatrix<MatrixType> sub(columns,first.IsLow(),first.GetData());
		MatrixType* pData1=(MatrixType*)sub.GetData();
		const MatrixType* pData2=second.GetData();
		int matrix_size=(columns)*(columns+1)/2;
		for(int index=0;index<matrix_size;index++) { pData1[index]-=pData2[index]; } // low level substraction
		// high level substraction
		//for(int j=0;j<columns;j++)
		//	for(int i=j;i<columns;i++) sub.SetIJ(i,j,first.(i,j)-second.(i,j) );
		return sub;
	}

	TriangleMatrix<MatrixType>& operator-=( const TriangleMatrix<MatrixType> &matrix )
	{
		assert( (matrix.GetRows()==GetRows())&&(matrix.GetColumns()==GetColumns())&&(matrix.IsLow()==IsLow()) );
		const MatrixType* pData2=matrix.GetData();
		for(int index=0;index<m_matrix_size;index++) { m_matrix[index]-=pData2[index]; } // low level substraction
		// high level substraction
		//for(int j=0;j<m_rows;j++)
		//	for(int i=j;i<m_columns;i++) SetIJ(i,j,(i,j)-matrix.(i,j) );
		return (*this);
	}

	// Muls a to scalar
	friend TriangleMatrix<MatrixType> operator*( const TriangleMatrix<MatrixType> &matrix, const MatrixType scalar)
	{
		int columns=matrix.GetColumns();
		TriangleMatrix<MatrixType> mul(columns,matrix.IsLow(),matrix.GetData());
		MatrixType* pData=(MatrixType*)mul.GetData();
		int matrix_size=(columns)*(columns+1)/2;
		for(int i=0;i<matrix_size;i++) pData[i]*=scalar; // low level mul
		// high level
		//for(int j=0;j<columns;j++)
		//	for(int i=j;i<columns;i++) mul.SetIJ(i,j,matrix.(i,j)*scalar);
		return mul;
	}

	friend TriangleMatrix<MatrixType> operator*( const MatrixType scalar,const TriangleMatrix<MatrixType> &matrix)
	{
		int columns=matrix.GetColumns();
		TriangleMatrix<MatrixType> mul(columns,matrix.IsLow(),matrix.GetData());
		MatrixType* pData=(MatrixType*)mul.GetData();
		int matrix_size=(columns)*(columns+1)/2;
		for(int i=0;i<matrix_size;i++) pData[i]*=scalar; // low level mul
		//TriangleMatrixUp<MatrixType> mul(columns);
		//for(int j=0;j<columns;j++)
		//	for(int i=j;i<columns;i++) mul.SetIJ(i,j,matrix.(i,j)*scalar);
		return mul;
	}

	TriangleMatrix<MatrixType>& operator*=(const MatrixType scalar)
	{
		for(int i=0;i<m_matrix_size;i++) m_matrix[i]*=scalar; // low level mul
		//for(int j=0;j<m_rows;j++)
		//	for(int i=j;i<m_columns;i++) SetIJ(i,j,(i,j)*scalar );
		return (*this);
	}

    ///// Stream operation overloading.
    //   Symmetric matrix out just its up triangle. ///
	friend ostream& operator<< ( ostream& os,const TriangleMatrix<MatrixType>& matrix )
	{
		int N=matrix.GetRows();
		os << N << Matrix<MatrixType>::DelimValue << (matrix.IsLow() ? 1 : 0) << Matrix<MatrixType>::DelimLine;
		for(int row=1;row<=N;row++)
		{
			int startColumn=row, endColumn=N;
			if(matrix.IsLow()) { startColumn=1; endColumn=row; }
			if(!matrix.IsLow()) for(int i=1;i<row;i++) os << "         ";
			for(int column=startColumn;column<=endColumn;column++)
			{
				os << Matrix<MatrixType>::FormValue << matrix(row,column) << Matrix<MatrixType>::DelimValue;
			}
			os << Matrix<MatrixType>::DelimLine;
		}
		return os;
	}

    ///// Input symmetric matrix.
    //   Symmetric matrix is defined with its up triangle. ///
	friend istream& operator>> ( istream& is,TriangleMatrix<MatrixType>& matrix )
	{
		int N,bLow;
		is >> N >> bLow;
		if(N!=matrix.GetRows()) matrix.ResetDimensions(N,N); // realloc memory if any
		for(int row=1;row<=N;row++)
		{
			int startColumn=row, endColumn=N;
			if(matrix.IsLow()) { startColumn=1; endColumn=row; }
			for(int column=startColumn;column<=endColumn;column++)
			{
				is >> matrix(row,column);
			}
		}
		return is;
	}

	// Copy operator
	TriangleMatrix<MatrixType>& operator=(const TriangleMatrix<MatrixType>& matrix)
	{
		_copyTR(matrix.GetRows(),matrix.IsLow(),matrix.GetData());
		return (*this);
	}

	void _copyTR(int columns,bool bLow,const MatrixType* initial_data)
	{
		if(m_matrix) { delete m_matrix; m_matrix=NULL; }
		assert(columns);
		m_columns=columns;
		m_rows=columns;
		m_bLow=bLow;
		m_matrix_size=m_columns*(m_rows+1)/2;
		assert(m_matrix_size);
		m_matrix=new MatrixType[m_matrix_size];
		assert(m_matrix);
		if(initial_data==NULL) memset(m_matrix,0,m_matrix_size*sizeof(MatrixType));
		else				   memcpy(m_matrix,initial_data,m_matrix_size*sizeof(MatrixType));
	}

    ///// Triangle matrix can be fast inversed.
    //   This function calculates inverse matrix and puts its elements into original matrix.
    //   The complexity of triangle matrix inversion is O( (n/6)^3 )
    /////
	virtual bool InverseItself(int bandSize=0)
	{
		int N=m_rows;
		for(int row=1;row<=N;row++)
		{
			MatrixType diagonal=(*this)(row,row);
			if(diagonal==0) return false;
			(*this)(row,row)=1/diagonal;
			for(int column=1;column<row;column++)
			{
				MatrixType sum=0;
				if(IsLow()) // inverse as low triangle matrix
				{
					for(int k=column;k<row;k++)
						sum+=( ((*this)(row,k))*((*this)(k,column)) );
					(*this)(row,column)=-sum/diagonal;
				}
				else
				{
					for(int k=column;k<row;k++)
						sum+=( ((*this)(k,row))*((*this)(column,k)) );
					(*this)(column,row)=-sum/diagonal;
				}
			}
		}
		return true;
	}

	virtual SquareMatrix<MatrixType> Inverse()
	{
		TriangleMatrix<MatrixType> matrix(m_rows,m_bLow,m_matrix);
		matrix.InverseItself();
		return matrix;
	}

};

/////
// Diagonal Matrix.
// Diagonal Matrix is matrix which elements equal 0 except in diagonal.
/////
template<class MatrixType> class DiagonalMatrix : public SquareMatrix<MatrixType>
{
protected:
    ///// matrix elements size */
	int m_matrix_size;
public:
    ///// Constructors.
    //   We store only diagonal elements.
    //   @param N - matrix dimension
    /////
	DiagonalMatrix() : SquareMatrix<MatrixType>() {}
	DiagonalMatrix(int N,const MatrixType* initial_data=NULL)
		: SquareMatrix<MatrixType>()
	{
		_copyD(N,initial_data);
	}

    ///// Copy constructor. ///
	DiagonalMatrix(const DiagonalMatrix<MatrixType>& init)
		//: SquareMatrix<MatrixType>()
	{
		_copyD(init.GetColumns(),init.GetData());
	}

    ///// Access operators. */
	const MatrixType operator()(int row,int column) const // get operator
	{
		row--;
		column--;
		assert((row>=0)&&(row<m_rows)&&(column>=0)&&(column<=m_columns));
		if(row!=column) return 0;
		return m_matrix[row];
	}
	MatrixType& operator()(int row,int column) // set operator
	{
		row--;
		column--;
		assert((row>=0)&&(row<m_rows)&&(column>=0)&&(column<=m_columns));
		assert(row==column); // can't set non diagonal elements
		return m_matrix[row];
	}

	virtual void ResetDimensions(int rows,int columns,const MatrixType* initial_data=NULL) // realloc matrix
	{
		assert(rows==columns);
		_copyD(rows,initial_data);
	}

    ///// Diagonal Matrix is transpose into itself. So the procedure returns its copy.*/
	DiagonalMatrix<MatrixType> Transpose()
	{
		assert(m_matrix);
		DiagonalMatrix<MatrixType> trmatrix(*this);
		return trmatrix;
	}

    ///// Diagonal Matrix is inverted into inself. Hence this procedure does nothing. ///
	virtual void TransposeItself() //diagonal matrix is transpose indeferent
	{
	}

private: ///// Internal helper function for the matrix initialization.
	void _copyD(int N,const MatrixType* initial_data)
	{
		m_columns=m_rows=N;
		if(m_matrix) { delete m_matrix; m_matrix=NULL; }
		m_matrix_size=N;
		m_matrix=new MatrixType[N];
		assert(m_matrix);
		if(initial_data==NULL) memset(m_matrix,0,m_matrix_size*sizeof(MatrixType));
		else				   memcpy(m_matrix,initial_data,m_matrix_size*sizeof(MatrixType));
	}

public:
    ///// Overdriving of operators to speed up specific matrix operation. ///
	friend DiagonalMatrix<MatrixType> operator+( const DiagonalMatrix<MatrixType> &first, const DiagonalMatrix<MatrixType> &second)
	{
		assert((first.GetRows()==second.GetRows())&&(first.GetColumns()==second.GetColumns()));
		int columns=first.GetColumns();
		DiagonalMatrix<MatrixType> sum(columns);
		for(int i=1;i<=columns;i++) sum(i,i)=first(i,i)+second(i,i); // high level summation
		return sum;
	}

	DiagonalMatrix<MatrixType>& operator+=(const DiagonalMatrix<MatrixType>& other)
	{
 		assert((other.GetRows()==m_columns)&&(other.GetColumns()==m_rows));
		for(int i=1;i<=m_rows;++i) (*this)(i,i)+=other(i,i);
		return (*this);
	}

	// Substraction
	friend DiagonalMatrix<MatrixType> operator-( const DiagonalMatrix<MatrixType> &first, const DiagonalMatrix<MatrixType> &second)
	{
		assert((first.GetRows()==second.GetRows())&&(first.GetColumns()==second.GetColumns()));
		int N=first.GetColumns();
		DiagonalMatrix<MatrixType> sub(N);
		for(int i=1;i<=N;i++) sub(i,i)=first(i,i)-second(i,i);
		return sub;
	}

	DiagonalMatrix<MatrixType>& operator-=(const DiagonalMatrix<MatrixType>& other)
	{
 		assert((other.GetRows()==m_columns)&&(other.GetColumns()==m_rows));
		for(int i=1;i<=m_rows;i++) (*this)(i,i)-=other(i,i);
		return (*this);
	}

	// Muls a to scalar
	friend DiagonalMatrix<MatrixType> operator*( const DiagonalMatrix<MatrixType> &matrix, const MatrixType scalar)
	{
		int N=matrix.GetColumns();
		DiagonalMatrix<MatrixType> mul(N);
		for(int i=1;i<=N;++i) mul(i,i)=matrix(i,i)*scalar;
		return mul;
	}

	friend DiagonalMatrix<MatrixType> operator*(const MatrixType scalar, const DiagonalMatrix<MatrixType> &matrix)
	{
		int columns=matrix.GetColumns();
		DiagonalMatrix<MatrixType> mul(columns);
		for(int i=0;i<columns;++i) mul(i,i)=matrix(i,i)*scalar;
		return mul;
	}

	DiagonalMatrix<MatrixType> operator*=(const MatrixType scalar)
	{
		for(int i=0;i<m_rows;++i) (*this)(i,i)*=scalar;
		return (*this);
	}

	// Stream operation overloading
	friend ostream& operator<< ( ostream& os,const DiagonalMatrix<MatrixType>& matrix )
	{
		os << matrix.GetColumns() << Matrix<MatrixType>::DelimLine;
		for(int i=1;i<=matrix.GetColumns();i++)
		{
			os << Matrix<MatrixType>::FormValue << matrix(i,i) << Matrix<MatrixType>::DelimLine;
		}
		os << Matrix<MatrixType>::DelimLine;
		return os;
	}

	// Input the matrix
	friend istream& operator>> ( istream& is,DiagonalMatrix<MatrixType>& matrix )
	{
		int N;
		is >> N;
		if(N!=matrix.GetColumns()) matrix.ResetDimensions(N,N); // realloc memory
		for(int i=1;i<=N;i++)
		{
			is >> matrix(i,i);
		}
		return is;
	}

	// Copy operator
	DiagonalMatrix<MatrixType>& operator=(const DiagonalMatrix<MatrixType>& matrix)
	{
		_copyD(matrix.GetColumns(),matrix.GetData());
		return (*this);
	}
};

/////
// Identity matrix.
// Identity matrix is diagonal matrix which diagonal elements equal 1.
/////
template<class MatrixType> class IdentityMatrix : public DiagonalMatrix<MatrixType>
{
public:
    ///// Constructor.
    //   We store nothing.
    //   Input: N - matrix dimension
    /////
	IdentityMatrix(int N)
		: DiagonalMatrix<MatrixType>()
	{
		_copyI(N);
	}

    ///// Copy constructor. ///
	IdentityMatrix(const IdentityMatrix<MatrixType>& init)
		//: SquareMatrix<MatrixType>()
	{
		_copyI(init.GetColumns());
	}

    ///// Access operators.
    //   Identity matrix restrict acceess.
    //   One only can get but can't set identity matrix elements.
    ///
	const MatrixType operator()(int row,int column) const // get operator
	{
		row--;
		column--;
		assert((row>=0)&&(row<m_rows)&&(column>=0)&&(column<=m_columns));
		if(row!=column) return 0;
		return 1;
	}
private:
	MatrixType& operator()(int row,int column) // set operator is forbidden
	{
		assert(false);
		return m_matrix[0];
	}
public:
	virtual void ResetDimensions(int rows,int columns,const MatrixType* initial_data=NULL) // realloc matrix
	{
		assert(rows==columns);
		assert(initial_data==NULL);
		_copyI(rows);
	}

private: ///// Internal helper function for the matrix initialization.
	void _copyI(int N)
	{
		m_columns=m_rows=N;
	}

private:
    ///// Overdriving of operators to forbid matrix change operation. ///
	IdentityMatrix<MatrixType>& operator+=(const DiagonalMatrix<MatrixType>& other)
	{
 		assert(false);
		return (*this);
	}

	IdentityMatrix<MatrixType>& operator-=(const DiagonalMatrix<MatrixType>& other)
	{
 		assert(false);
		return (*this);
	}

	DiagonalMatrix<MatrixType> operator*=(const MatrixType scalar)
	{
 		assert(false);
		return (*this);
	}

    ///// One can't input identity matrix /////
	friend istream& operator>> ( istream& is,DiagonalMatrix<MatrixType>& matrix )
	{
 		assert(false);
		return is;
	}

public:
	// Copy operator
	IdentityMatrix<MatrixType>& operator=(const IdentityMatrix<MatrixType>& matrix)
	{
		_copyI(matrix.GetColumns());
		return (*this);
	}
/*
	// Stream operation overloading
	friend ostream& operator<< ( ostream& os,const IdentityMatrix<MatrixType>& matrix )
	{
		os << matrix.GetColumns() << Matrix<MatrixType>::DelimLine;
		for(int i=1;i<=matrix.GetColumns();i++)
		{
			os << Matrix<MatrixType>::FormValue << 1 << Matrix<MatrixType>::DelimLine;
		}
		os << Matrix<MatrixType>::DelimLine;
		return os;
	}
*/
};

/*
// Don't debug yet
template<class MatrixType> class BandMatrix : public SquareMatrix<MatrixType>
{
	int m_Z; // band width
	int m_columnsatrix_size;
	int m_full_lines,m_unfull_lines;
public:
	BandMatrix(int columns,int Z) : SquareMatrix<MatrixType>(1)
	{
		delete m_matrix;
		m_Z=Z;
		m_rows=m_columns=columns;
		m_unfull_lines=m_rows%m_Z // number of unfull lines
		m_full_lines=m_rows-n2; // number of full lines
		m_columnsatrix_size=m_full_lines*m_Z+m_unfull_lines*(m_unfull_lines+1)/2;
		m_matrix=new MatrixType(m_columnsatrix_size);
	}

	virtual MatrixType (const int i,const int j) const
	{
		assert((i>=0)&&(i<m_columns)&&(j>=0)&&(j<=m_rows));
		assert(i>=j); // up triangle
		if(j<=m_full_lines) { assert( (i-j)<m_Z ); }
		int index;
		if(j<m_full_lines)
		{
			index=j*m_Z+i;
		}
		else
		{
			index=m_full_lines*m_Z+(j-m_unfull_lines)*(j-m_unfull_lines+1)/2+i;
		}
		return m_matrix[index];
	}

	virtual MatrixType SetIJ(const int i,const int j,const MatrixType v)
	{
		assert((i>=0)&&(i<m_columns)&&(j>=0)&&(j<=m_rows));
		assert(i>=j); // up triangle
		if(j<=m_full_lines) { assert( (i-j)<m_Z ); }
		int index;
		if(j<m_full_lines)
		{
			index=j*m_Z+i;
		}
		else
		{
			index=m_full_lines*m_Z+(j-m_unfull_lines)*(j-m_unfull_lines+1)/2+i;
		}
		m_matrix[index]=v;
	}
};
*/


/////////////////////////////////////////////////////////////
//
// Matrixes for Adjust1 program
//
/////////////////////////////////////////////////////////////

/////
//   A Matrix that can change its size (can grow).
//   Such matrix is usefull for recurrent adjustment.
///
template<class MatrixType> class GrowMatrix : public Matrix<MatrixType>
{
protected:
	int m_max_rows,m_max_columns;
	int m_matrix_size;
public:
	GrowMatrix() { m_matrix=NULL; m_max_rows=m_max_columns=m_matrix_size=-1; }

	GrowMatrix(int MaxRows,int MaxColumns,int InitialRows,int InitialColumns)
		: Matrix<MatrixType>(MaxRows,MaxColumns)
	{
		m_rows=InitialRows;
		m_columns=InitialColumns;
		m_max_rows=MaxRows;
		m_max_columns=MaxColumns;
	}

	// two copy constructors
	GrowMatrix(const GrowMatrix<MatrixType>& initial_matrix)
	{
		m_matrix=NULL;
		_copyG( initial_matrix.GetMaxRows(),initial_matrix.GetMaxColumns(),
			    initial_matrix.GetRows(),initial_matrix.GetColumns(),
			    initial_matrix.GetData() );
	}

	GrowMatrix(const Matrix<MatrixType>& initial_matrix)
	{
		m_matrix=NULL;
		_copyG(initial_matrix.GetRows(),initial_matrix.GetColumns(),initial_matrix.GetRows(),initial_matrix.GetColumns(),initial_matrix.GetData());
	}

    ///// returns its parameters ///
	int GetMaxRows() const { return m_max_rows; }
	int GetMaxColumns() const { return m_max_columns; }

    /// Change matrix dimensions without its realocation.
    //   @param Rows, Columns - new numbers of row/columns for the matrix
    //                           (they must be less than MaxRows and MaxColumns)
    ///
	void ChangeSize(int rows, int columns)
	{
		assert(rows<=m_max_rows);
		assert(columns<=m_max_columns);
		m_rows=rows;
		m_columns=columns;
	}

    /// Grow the matrix without its realocation.
    //   @param Rows, Columns - new numbers of row/columns for the matrix
    //                           (they must be less than MaxRows and MaxColumns)
    ///
	void Grow(int rows, int columns)
	{
		if((rows>m_rows)||(columns>m_columns)) ChangeSize(rows,columns);
	}

protected:
	void _copyG(int MaxRows,int MaxColumns,int InitialRows,int InitialColumns,const MatrixType* initial_data)
	{
		assert(MaxRows>0);
		assert(MaxColumns>0);
		assert(InitialRows>0);
		assert(InitialColumns>0);
		m_rows=InitialRows;
		m_columns=InitialColumns;
		m_max_rows=MaxRows;
		m_max_columns=MaxColumns;

		m_matrix_size=(m_max_rows)*(m_max_columns);
		if(m_matrix!=NULL) { delete m_matrix; m_matrix=NULL; }
		m_matrix=new MatrixType[m_matrix_size];
		assert(m_matrix);
		if(initial_data==NULL) memset(m_matrix,0,m_matrix_size*sizeof(MatrixType));
		else						  memcpy(m_matrix,initial_data,m_matrix_size*sizeof(MatrixType));
	}

public:

	virtual void ResetDimensions(int MaxRows,int MaxColumns,
								 int InitialRows,int InitialColumns,
								 const MatrixType* initial_data=NULL) // realloc matrix
	{
		_copyG(MaxRows,MaxColumns,InitialRows,InitialColumns,initial_data);
	}

    ///// Returns matrix element at given row,column
    //   @param row,column - count starts with 1 (0 is wrong number for column or row)
    //   @return element at given row/column
    ///
	virtual const MatrixType operator() (int row,int column) const
	{
		row--;
		column--;
		assert((row>=0)&&(row<m_rows)&&(column>=0)&&(column<m_columns));
		return m_matrix[row*m_max_columns+column];
	}

    ///// Sets matrix element at given row,column
    //   @param row,column - Amn
    //   Returns pointer to given element
    ///
	virtual MatrixType& operator() (int row,int column)
	{
		row--;
		column--;
		assert((row>=0)&&(row<m_rows)&&(column>=0)&&(column<m_columns));
		return m_matrix[row*m_max_columns+column];
	}

	/////////////////////////////////////////////////////////////////////
	// Matrix Operators
	// Operator overloaded using a member function

	// Copping of a matrix
	GrowMatrix<MatrixType>& operator=(const GrowMatrix<MatrixType>& matrix)
	{
		_copyG(matrix.GetMaxRows(),matrix.GetMaxColumns(),
			   matrix.GetRows(),matrix.GetColumns(),matrix.GetData());
		return *this;
	}

	Matrix<MatrixType>& operator=(const Matrix<MatrixType>& matrix)
	{
		int rows=matrix.GetRows();
		int columns=matrix.GetColumns();
		_copyG(rows,columns,rows,columns,NULL);
		for(int row=1;row<=rows;row++)
			for(int column=1;column<=columns;column++) (*this)(row,column)=matrix(row,column);
		return *this;
	}

};


/////
// Vector (column or row) that can change its size.
// (Vector is matrix which a dimension equals to 1).
/////
template<class MatrixType> class GrowVector : public Vector<MatrixType>
{
protected:
	int m_max_rows,m_max_columns;
public:
    ///// Constructor.
    //   @param MaxN - number of vector elements to allocate
    //   @param InitialN - number of vector elements to initiate
    //   @param bRow - indicates type of vector (row if true or column if false)
    //   @param initial_data - initial data for the vector
    /////
	GrowVector(bool bRow=false) : Vector<MatrixType>(bRow) { }
	GrowVector(int MaxN,int InitialN, bool bRow=false, const MatrixType* initial_data=NULL)
		: Vector<MatrixType>(MaxN,bRow,initial_data) // allock memory for data
	{
		if(m_bRow)	{ m_columns=InitialN;	m_rows=1;	 m_max_columns=MaxN;	m_max_rows=1;}
		else		{ m_rows=InitialN;		m_columns=1; m_max_rows=MaxN;		m_max_columns=1;}
	}

    ///// Transposition for row is its conversion to column
    //   and transposition for column is its conversion to row
    ///
	virtual Matrix<MatrixType> Transpose() const
	{
		if(m_bRow) { return GrowVector<MatrixType>(m_max_columns,m_columns,!m_bRow,m_matrix); }
		else	   { return GrowVector<MatrixType>(m_max_rows,m_rows,!m_bRow,m_matrix);	}
	}

    ///// Transposition for row is its conversion to column
    //   and transposition for column is its conversion to row
    ///
	virtual void TransposeItself()
	{
		m_bRow=!m_bRow;
		// swap columns<->rows
		int swap=m_columns; m_columns=m_rows; m_rows=swap;
		int swap_max=m_max_columns; m_max_columns=m_max_rows; m_max_rows=swap_max;
	}

	virtual void ResetDimensions(int MaxN,int InitialN,const MatrixType* initial_data=NULL) // realloc matrix
	{
		Vector<MatrixType>::ResetDimensions(MaxN,initial_data);
		if(m_bRow)	{ m_columns=InitialN;	m_rows=1;	 m_max_columns=MaxN;	m_max_rows=1;}
		else		{ m_rows=InitialN;		m_columns=1; m_max_rows=MaxN;		m_max_columns=1;}
	}

    /// Cahnge vector size without its realocation.
    //   @param new_size - new numbers of row(columns) for the matrix
    //                           (they must be less than MaxRows and MaxColumns)
    ///
	void ChangeSize(int new_size)
	{
		if(m_bRow)
		{
			assert(new_size<=m_max_columns);
			m_columns=new_size;
		}
		else
		{
			assert(new_size<=m_max_rows);
			m_rows=new_size;
		}
	}

    /// Grow vector without its realocation.
    //   @param new_size - new numbers of row(columns) for the matrix
    //                           (they must be less than MaxRows and MaxColumns)
    ///
	void Grow(int new_size)
	{
		if(m_bRow)
		{
			if(new_size<=m_columns) return;
			assert(new_size<=m_max_columns);
			m_columns=new_size;
		}
		else
		{
			if(new_size<=m_rows) return;
			assert(new_size<=m_max_rows);
			m_rows=new_size;
		}
	}

};


/////
//   A Symmetric Matrix that can change its size.
///
template<class MatrixType> class SymmetricGrowMatrix : public GrowMatrix<MatrixType>,
													   public SymmetricMatrix<MatrixType>
{
public:
	SymmetricGrowMatrix() : GrowMatrix<MatrixType>(),SymmetricMatrix<MatrixType>() {}
	SymmetricGrowMatrix(int MaxN,int InitialN,const MatrixType* initial_data=NULL)
		: GrowMatrix<MatrixType>(),SymmetricMatrix<MatrixType>()
	{
		assert(MaxN>=InitialN);
		_copyGS(MaxN,InitialN,initial_data);
	}

    ///// Copy Constructor ///
	SymmetricGrowMatrix(const SymmetricGrowMatrix& init)
	{
		_copyGS(init.GetMaxRows(),init.GetRows(),init.GetData());
	}

    ///// Returns number of rows in the matrix ///
	int GetRows() const { return SymmetricMatrix<MatrixType>::m_rows; }
    ///// Returns number of columns in the matrix ///
	int GetColumns() const { return SymmetricMatrix<MatrixType>::m_columns;  }
    ///// Retruns data storage.   /////
	const MatrixType* GetData() const { return SymmetricMatrix<MatrixType>::m_matrix; }

    /// Change matrix size without its realocation.
    //   @param Rows, Columns - new numbers of row/columns for the matrix
    //                           (they must be less than MaxRows and MaxColumns)
    ///
	void ChangeSize(int rows, int columns)
	{
		assert(rows==columns);
		ChangeSize(rows);
	}
	void ChangeSize(int NewSize)
	{
		assert(NewSize>0);
		assert(NewSize<=m_max_rows);
		SymmetricMatrix<MatrixType>::m_rows=SymmetricMatrix<MatrixType>::m_columns=NewSize;
	}

    /// Grow matrix without its realocation.
    //   @param Rows, Columns - new numbers of row/columns for the matrix
    //                           (they must be less than MaxRows and MaxColumns)
    ///
	void Grow(int rows, int columns)
	{
		assert(rows==columns);
		Grow(rows);
	}
	void Grow(int NewSize)
	{
		assert(NewSize>0);
		if(NewSize>SymmetricMatrix<MatrixType>::m_rows) ChangeSize(NewSize);
	}

    ///// Redefine the access operators for new data store model. ///
	const MatrixType operator() (int row, int column) const // get operator
	{
		assert((row>=1)&&(row<=m_max_rows)&&
			   (column>=1)&&(column<=m_max_columns));
		// we store only up triangle of the matrix
		// so if one requires data from low triangle then simple swap row and column.
		if(row>column) { int swap=row; row=column; column=swap; }
		// data are stored with division on columns
		int index=(column*column-column)/2+row-1;
		return SymmetricMatrix<MatrixType>::m_matrix[index];
	}
	MatrixType& operator() (int row, int column) // set operator
	{
		assert((row>=1)&&(row<=SymmetricMatrix<MatrixType>::m_rows)&&(column>=1)&&(column<=SymmetricMatrix<MatrixType>::m_columns));
		// we store only up triangle of the matrix
		// so if one requires data from low triangle then simple swap row and column.
		if(row>column) { int swap=row; row=column; column=swap; }
		// data are stored with division on columns
		int index=(column*column-column)/2+row-1;
		return SymmetricMatrix<MatrixType>::m_matrix[index];
	}

    ///// Redefine dimension change routine for new data store model. ///
	virtual void ResetDimensions(int rows,int columns,
								 int InitialRows,int InitialColumns,
								 const MatrixType* initial_data=NULL) // realloc matrix
	{
		assert(rows==columns); // symmetric matrix demands Rows==Columns
		assert(InitialRows==InitialColumns); // symmetric matrix demands Rows==Columns
		_copyGS(rows,InitialRows,initial_data);
	}

	// Copy operator
	SymmetricGrowMatrix<MatrixType>& operator=(const SymmetricGrowMatrix<MatrixType>& matrix)
	{
		_copyGS(matrix.GetMaxRows(),matrix.GetRows(),matrix.GetData());
		return (*this);
	}

	void _copyGS(int MaxN,int N,const MatrixType* initial_data)
	{
		if(GrowMatrix<MatrixType>::m_matrix) { delete GrowMatrix<MatrixType>::m_matrix; GrowMatrix<MatrixType>::m_matrix=NULL; }
		if(SymmetricMatrix<MatrixType>::m_matrix) { delete SymmetricMatrix<MatrixType>::m_matrix; SymmetricMatrix<MatrixType>::m_matrix=NULL; }
		assert(MaxN>0);
		assert(N>0);
		assert(MaxN>=N);
		SymmetricMatrix<MatrixType>::m_columns=SymmetricMatrix<MatrixType>::m_rows=
		GrowMatrix<MatrixType>::m_columns=GrowMatrix<MatrixType>::m_rows = N;
		m_max_columns=m_max_rows=MaxN;
		SymmetricMatrix<MatrixType>::m_matrix_size=m_max_rows*(m_max_rows+1)/2;
		assert(SymmetricMatrix<MatrixType>::m_matrix_size);
		SymmetricMatrix<MatrixType>::m_matrix=new MatrixType[SymmetricMatrix<MatrixType>::m_matrix_size];
		assert(SymmetricMatrix<MatrixType>::m_matrix);
		if(initial_data==NULL) memset(SymmetricMatrix<MatrixType>::m_matrix,0,SymmetricMatrix<MatrixType>::m_matrix_size*sizeof(MatrixType));
		else				   memcpy(SymmetricMatrix<MatrixType>::m_matrix,initial_data,SymmetricMatrix<MatrixType>::m_matrix_size*sizeof(MatrixType));
	}

};


/////
//   A Symmetric Grow Matrix that is stored in disk file
///
template<class MatrixType> class CashableSymmetricGrowMatrix : public SymmetricGrowMatrix<MatrixType>
{
protected:
	long m_cash_size;
	mutable int m_min_locked_index,m_max_locked_index;
    MatrixType *m_cash;
    FILE* m_cash_file;
public:
	CashableSymmetricGrowMatrix<MatrixType>() : SymmetricGrowMatrix<MatrixType>() 
	{ 
		m_cash=NULL;
		m_cash_size=-1; 
		m_cash_file=NULL;
	}

	CashableSymmetricGrowMatrix<MatrixType>(int MaxN,int InitialN,int CashSize=262144L) // 262144=512*512
        : SymmetricGrowMatrix<MatrixType>()
	{
		assert(MaxN>=InitialN);
		_copyCGS(MaxN,InitialN,CashSize);
	}

    ~CashableSymmetricGrowMatrix<MatrixType>()
    {
		if(m_cash_size<=0) return;
		CloseCashFile();
		if(m_cash!=NULL) { delete m_cash; m_cash=NULL; }
    }

	int GetCashSize() const	{ return m_cash_size; }
	virtual void ResetDimensions(int rows,int columns,
								 int InitialRows,
								 int cash_size,
								 const MatrixType* initial_data=NULL) // realloc matrix
	{
		assert(rows==columns); // symmetric matrix demands Rows==Columns
		//assert(InitialRows==InitialColumns); // symmetric matrix demands Rows==Columns
		_copyCGS(rows,InitialRows,cash_size,initial_data);
	}

    ///// Copy Constructor is disable///
private:
	CashableSymmetricGrowMatrix(const CashableSymmetricGrowMatrix& init)
	{
		_copyCGS(init.GetMaxRows(),init.GetRows(),init.GetCashSize(),init.GetData());
	}

	// Copy operator
	CashableSymmetricGrowMatrix<MatrixType>& operator=(const CashableSymmetricGrowMatrix<MatrixType>& matrix)
	{
		_copyCGS(matrix.GetMaxRows(),matrix.GetRows(),matrix.GetCashSize(),matrix.GetData());
		return (*this);
	}

public:
    ///// Redefine the access operators for new data store model. ///
	const MatrixType operator() (int row, int column) const// get operator
	{
		if(m_cash_size<=0) return SymmetricGrowMatrix<MatrixType>::operator()(row,column);
		assert((row>=1)&&(row<=m_max_rows)&&
			   (column>=1)&&(column<=m_max_columns));
		// we store only up triangle of the matrix
		// so if one requires data from low triangle then simple swap row and column.
		if(row>column) { int swap=row; row=column; column=swap; }
		// data are stored with division on columns
		int index=(column*column-column)/2+row-1;
        if(index<m_min_locked_index) // to lower indexes
        {
            Unlock();
            m_min_locked_index=m_min_locked_index-m_cash_size;
            if(m_min_locked_index<0) m_min_locked_index=0;
            if(m_max_locked_index>SymmetricMatrix<MatrixType>::m_matrix_size) m_max_locked_index=SymmetricMatrix<MatrixType>::m_matrix_size;
            m_max_locked_index=m_min_locked_index+m_cash_size;
            Lock();
        }
        if(index>=m_max_locked_index) // to upper indexes
        {
            Unlock();
            m_max_locked_index=m_max_locked_index+m_cash_size;
            if(m_max_locked_index>SymmetricMatrix<MatrixType>::m_matrix_size) m_max_locked_index=SymmetricMatrix<MatrixType>::m_matrix_size;
            m_min_locked_index=m_max_locked_index-m_cash_size;
            if(m_min_locked_index<0) m_min_locked_index=0;
            Lock();
        }
        return m_cash[index-m_min_locked_index];
	}
	MatrixType& operator() (int row, int column) // set operator
	{
		if(m_cash_size<=0) return SymmetricGrowMatrix<MatrixType>::operator()(row,column);
		assert((row>=1)&&(row<=SymmetricMatrix<MatrixType>::m_rows)&&(column>=1)&&(column<=SymmetricMatrix<MatrixType>::m_columns));
		// we store only up triangle of the matrix
		// so if one requires data from low triangle then simple swap row and column.
		if(row>column) { int swap=row; row=column; column=swap; }
		// data are stored with division on columns
		int index=(column*column-column)/2+row-1;
        if(index<m_min_locked_index) // to lower indexes
        {
            Unlock();
            m_min_locked_index=m_min_locked_index-m_cash_size;
            if(m_min_locked_index<0) m_min_locked_index=0;
            if(m_max_locked_index>SymmetricMatrix<MatrixType>::m_matrix_size) m_max_locked_index=SymmetricMatrix<MatrixType>::m_matrix_size;
            m_max_locked_index=m_min_locked_index+m_cash_size;
            Lock();
        }
        if(index>=m_max_locked_index) // to upper indexes
        {
            Unlock();
            m_max_locked_index=m_max_locked_index+m_cash_size;
            if(m_max_locked_index>SymmetricMatrix<MatrixType>::m_matrix_size) m_max_locked_index=SymmetricMatrix<MatrixType>::m_matrix_size;
            m_min_locked_index=m_max_locked_index-m_cash_size;
            if(m_min_locked_index<0) m_min_locked_index=0;
            Lock();
        }
        return m_cash[index-m_min_locked_index];
	}

    void _copyCGS(int MaxN,int N,int CashSize,const MatrixType* initial_data=NULL)
	{
		if(CashSize<=0) return;
        // 1. close all previous opened
		if(GrowMatrix<MatrixType>::m_matrix) { delete GrowMatrix<MatrixType>::m_matrix; GrowMatrix<MatrixType>::m_matrix=NULL; }
		if(SymmetricMatrix<MatrixType>::m_matrix) { delete SymmetricMatrix<MatrixType>::m_matrix; SymmetricMatrix<MatrixType>::m_matrix=NULL; }
        if(m_cash) { delete m_cash; m_cash=NULL; }
        CloseCashFile();
        // 2. define variables
		assert(MaxN>0);
		assert(N>0);
		assert(MaxN>=N);
		SymmetricMatrix<MatrixType>::m_columns=SymmetricMatrix<MatrixType>::m_rows=
		GrowMatrix<MatrixType>::m_columns=GrowMatrix<MatrixType>::m_rows = N;
		m_max_columns=m_max_rows=MaxN;
		SymmetricMatrix<MatrixType>::m_matrix_size=m_max_rows*(m_max_rows+1)/2;
		assert(SymmetricMatrix<MatrixType>::m_matrix_size>0);
        // 3. create cash file and fill with initial data
        m_cash_file=tmpfile();
		m_cash_size=CashSize;
        if(initial_data==NULL) 
		{
			//_chsize(SymmetricMatrix<MatrixType>::m_matrix_size*sizeof(MatrixType));
			MatrixType value=0;
			for(int i=0;i<SymmetricMatrix<MatrixType>::m_matrix_size;i++)
			{
				fwrite(&value,sizeof(value),1,m_cash_file);
			}
		}
        else fwrite(initial_data,SymmetricMatrix<MatrixType>::m_matrix_size*sizeof(MatrixType),1,m_cash_file);
        // 4. create memory cash
        m_cash=new MatrixType[m_cash_size];
        assert(m_cash);
        // 4. load data from
        m_min_locked_index=0;
        m_max_locked_index=m_min_locked_index+m_cash_size;
		if(m_max_locked_index>SymmetricMatrix<MatrixType>::m_matrix_size) m_max_locked_index=SymmetricMatrix<MatrixType>::m_matrix_size;
        Lock();
	}

    void Lock() const 
    {
		if(m_cash_size<=0) return;
		if(m_cash_file==NULL) return;
        fseek(m_cash_file,m_min_locked_index*sizeof(MatrixType),SEEK_SET);
        fread(m_cash,m_cash_size*sizeof(MatrixType),1,m_cash_file);
    }
    void Unlock() const
    {
		if(m_cash_size<=0) return;
		if(m_cash_file==NULL) return;
        fseek(m_cash_file,m_min_locked_index*sizeof(MatrixType),SEEK_SET);
        fwrite(m_cash,m_cash_size*sizeof(MatrixType),1,m_cash_file);
    }
    void CloseCashFile()
    {
		if(m_cash_file==NULL) return;
        Unlock();
        fflush(m_cash_file);
        fclose(m_cash_file);
        _rmtmp();
    }

};

#endif