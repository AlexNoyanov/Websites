
<!DOCTYPE html>
<html lang=ru-ru dir=ltr>
<head>
  
 <meta charset=utf-8 />


<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>
<body>

<style type="text/css">
  .main {
  margin-left: 240px; /* Same width as the sidebar + left position in px */
  font-size: 28px;    /* Increased text to enable scrolling */
  padding: 0px 10px;
}

</style>

  <?php include "./index.php" ?>


<div class = 'bodyStyle'>
  <div class="main">

 <h3>Домашняя страница сайта тут!</h3>
 <p>Этот сайт создан в качестве курсовой работы по курсу Веб-технологий</p>
 <p>студентом кафедры ИВТИ Александром Нояновым. Здесь Вы найдете ресурсы</p>
 <p>по темам в меню</p>
 <div id = '#home'>
   Home text here...
  </div>
</div>
</div>


</body>
</html>